//
// Created by kun on 25-7-17.
//

#ifndef IST8310_H
#define IST8310_H
#include "main.h"
#define IST8310_DATA_READY_BIT 2
#define IST8310_AVGCNTL 0x41 //采样平均寄存器
#define IST8310_NO_ERROR 0x00
#define IST8310_NO_SENSOR 0x40

/*------------采样次数-------------*/

typedef enum
{
    IST8310_AVGCNTL_1=00,
    IST8310_AVGCNTL_2=01,
    IST8310_AVGCNTL_4=10,
    IST8310_AVGCNTL_8=11,
    IST8310_AVGCNTL_16=100,
}IST8310_AVGCNTL_x;
typedef struct ist8310_real_data_t
{
    uint8_t status;
    fp32 mag[3];
} ist8310_real_data_t;

extern uint8_t ist8310_init(void);
extern void ist8310_read_over(uint8_t *status_buf, ist8310_real_data_t *mpu6500_real_data);
extern void ist8310_read_mag(fp32 mag[3]);
extern void ist8310_average_sampling(void);

#endif //IST8310_H
